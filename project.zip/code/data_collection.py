######################################
# useful functions for data collection
######################################

from tqdm.notebook import tqdm
from itertools import zip_longest
from datetime import datetime
import pandas as pd
import pickle
import time
from io import BytesIO
from zipfile import ZipFile
from urllib.error import HTTPError
from urllib.error import URLError
from urllib.request import urlopen
from multiprocessing import Pool
from concurrent import futures
from datetime import timedelta

def get_timestamp(url):
    # convert the url into a datetime object
    
    if(len(url)<40):
        # this is needed because some timestamps are missing
        # probably due to server maintenance
        return None
    
    url=url.split("/")[-1].split(".")[0]
    datetime_object = datetime.strptime(url, '%Y%m%d%H%M%S')
    
    return datetime_object

def datetime_to_url(datetime):
    # retrieve the event and mention url from the timestamps
    datetime = datetime.strftime('%Y%m%d%H%M%S')
    url_mentions="http://data.gdeltproject.org/gdeltv2/"+datetime+".mentions.CSV.zip"
    url_export="http://data.gdeltproject.org/gdeltv2/"+datetime+".export.CSV.zip"
    return (url_mentions, url_export)

def string_to_url(timestamp):
    # retrieve the event and mention url from the timestamps
    url_mentions="http://data.gdeltproject.org/gdeltv2/"+timestamp+".mentions.CSV.zip"
    url_export="http://data.gdeltproject.org/gdeltv2/"+timestamp+".export.CSV.zip"
    return (url_mentions, url_export)

def get_url_type(url):
    # get the url type (export, mentions, gkg)
    return url.split("/")[-1].split(".")[1]

def load_pickle(path):
    with open(path, 'rb') as handle:
        temp = pickle.load(handle)
    return(temp)

def generate_record_dict():
    # retrieves all the timestamps from the masterfilelist
    
    # get the url list
    all_url = []
    with open("../data/masterfilelist.txt" , 'r') as f:
        for idx, lines in enumerate(f.readlines()):
            lines=lines.split()[-1]

            # this is needed to avoid lines with missing info
            # (probably due to server maintenance)
            if len(lines)>40:
                all_url.append(lines)
                
    # get all the timestamps
    all_timestamps = []
    for i in range(len(all_url)):
        if get_url_type(all_url[i]) == 'export':
            all_timestamps.append(get_timestamp(all_url[i]))

    all_timestamps = sorted(list(filter(lambda item: item is not None, all_timestamps)))
    
    # save the timestamps in a dictionary to keep track of downloaded files
    data_record_dict = {}
    data_record_dict['all'] = all_timestamps
    data_record_dict['downloaded'] = []
    data_record_dict['missing'] = all_timestamps
    
    # save the dictionary to disk
    with open('../data/data_record_dict.pickle', 'wb') as handle:
        pickle.dump(data_record_dict, handle, protocol=pickle.HIGHEST_PROTOCOL)
        
    
    # initialize the new data files
    with open('../data/events.tsv', 'w') as f:
        pass
    with open('../data/mentions.tsv', 'w') as f:
        pass
    
    return

def update_record(data_record_dict, downloaded):
    # update downloaded ones
    data_record_dict['downloaded'].extend( [data_record_dict['missing'][i] for i in downloaded] )
    # remove downloaded from missing list
    data_record_dict['missing'] = [value for idx, value in enumerate(data_record_dict['missing']) if idx not in downloaded]
    # update the record on disk
    with open('../data/data_record_dict.pickle', 'wb') as handle:
        pickle.dump(data_record_dict, handle, protocol=pickle.HIGHEST_PROTOCOL)
    return

def get_interval(data_record_dict, size = None, start_date = None, end_date = None):
    # download, preprocess and save data
    # size:        number of files to download
    # start_date:  from when to start downloading
    # date_range:  when to finish downloading
    
    if isinstance(start_date, str):
        start_date = datetime.strptime(start_date, '%Y%m%d%H%M%S')
    
    if isinstance(end_date, str):
        end_date = datetime.strptime(end_date, '%Y%m%d%H%M%S')
    
    
    if size == None and ((start_date is None) or (end_date is None)):
        raise ValueError('Missing size or date range arguments')
    
    if size is None:
        size = len(data_record_dict['missing'])
    
    if start_date is None:
        start_date = data_record_dict['missing'][0]
    
    if end_date is None:
        end_date = data_record_dict['missing'][-1]
    
    what_idx = []
    what_dates = []
    
    count = 0
    for idx, date in enumerate(data_record_dict['missing']):
        if count >= size:
            break
        if date >= start_date and date <= end_date:
            what_idx.append(idx)
            what_dates.append(date.strftime('%Y%m%d%H%M%S'))
            count += 1
    
    return(what_dates, what_idx)
    
    
def task(timestamp):
    # download and preprocess data starting from the timestamp
    # timestamp: str

    # get the url
    url_mentions, url_export = string_to_url(timestamp)
    
    for _ in range(20):
        # instantiate the connection
        try:
            resp_mentions = urlopen(url_mentions)
            resp_export = urlopen(url_export)
            break
        except HTTPError as e:
            # some url are empty
            return
        except OSError as e:
            time.sleep(1)
    

    # download the files and instantiate the unzipper
    zipfile_mentions = ZipFile(BytesIO(resp_mentions.read()))
    zipfile_export = ZipFile(BytesIO(resp_export.read()))
    
    # unzip and preprocess
    mentions = pd.read_csv(zipfile_mentions.open(zipfile_mentions.namelist()[0]), sep = '\t', names = full_mention_header.keys(), dtype = full_mention_header, usecols = mention_header_numbering)
    try:
        export = pd.read_csv(zipfile_export.open(zipfile_export.namelist()[0]), sep = '\t', names = full_event_header.keys(), dtype = full_event_header, usecols = event_header_numbering)
    except ValueError as e:
        new_dict = full_event_header.copy()
        new_dict['Actor1Geo_Lat'] = 'unicode'
        new_dict['Actor2Geo_Lat'] = 'unicode'
        new_dict['ActionGeo_Lat'] = 'unicode'
        new_dict['Actor1Geo_Long'] = 'unicode'
        new_dict['Actor2Geo_Long'] = 'unicode'
        new_dict['ActionGeo_Long'] = 'unicode'
        export = pd.read_csv(zipfile_export.open(zipfile_export.namelist()[0]), sep = '\t', names = full_event_header.keys(), dtype = new_dict, usecols = event_header_numbering)
        export['ActionGeo_Lat'] = export['ActionGeo_Lat'].str.replace('#','').astype('float32')
        export['ActionGeo_Long'] = export['ActionGeo_Long'].str.replace('#','').astype('float32')
        
    # close the unzipper instances
    zipfile_mentions.close()
    zipfile_export.close()

    return(export, mentions)

def download_extract(size = None, start_date = None, end_date = None, num_workers = 16, chunksize = 10, update_interval=1):
    # download, preprocess and save data
    # size:        number of files to download
    # start_date:  from when to start downloading
    # date_range:  when to finish downloading
    
    # declare original headers as global variables
    global full_event_header, full_mention_header, event_header_numbering, mention_header_numbering
    
    # get data record dictionary and file headers
    data_record_dict = load_pickle('../data/data_record_dict.pickle')
    full_event_header = load_pickle('../data_utils/full_event_header.pickle')
    full_mention_header = load_pickle('../data_utils/full_mention_header.pickle')
    event_header_numbering = load_pickle('../data_utils/event_header_numbering.pickle')
    mention_header_numbering = load_pickle('../data_utils/mention_header_numbering.pickle')

    # retrieve timestamps to download
    what_to_download, downloaded = get_interval(data_record_dict, size = size, start_date = start_date, end_date = end_date)
    
    def track_job(job):
        start = time.time()
        while job._number_left > 0:
            print("Tasks remaining = {0}--------------\r".format(
            job._number_left * job._chunksize), end = '')
            time.sleep(update_interval)
        print("Done-----------------------Total = {:.2f}s".format(time.time()-start))
    
    #pbar = tqdm(total=len(what_to_download))

    result_list = []
    with Pool(num_workers) as pool:
        # issue tasks and process results
        value = pool.map_async(task, what_to_download, chunksize = chunksize)
        track_job(value)
        for result in value.get():
        # for result in pool.map_async(task, what_to_download, chunksize = chunksize):
            result_list.append(result)
        #     pbar.update(1)
        # pbar.close()
    
    '''# instantiate progress bar
    pbar = tqdm(total=len(what_to_download))

    result_list = []
    with Pool(num_workers) as pool:
        # issue tasks and process results
        for result in pool.imap_unordered(task, what_to_download, chunksize = chunksize):
            result_list.append(result)
            pbar.update(1)
        pbar.close()'''
    
    ################ ALTERNATIVE APPROACHES #########################
    '''
    with Pool(num_workers) as pool:
        result_list = list(pool.apply_async(task, args=(i, )) for i in what_to_download)
        result_list = [r.get() for r in tqdm(result_list)]

    with Pool(num_workers) as pool:
        result_list = list(tqdm((pool.apply(task, args=[i]) for i in what_to_download), total=len(what_to_download)))

    pbar = tqdm(total=len(what_to_download))

    result_list = []
    with Pool(num_workers) as pool:
        # issue tasks and process results
        for result in pool.map_async(task, what_to_download, chunksize = chunksize):
            result_list.append(result)
            pbar.update(1)
        pbar.close()
    
    
    pbar = tqdm(total=len(what_to_download))

    result_list = []
    with futures.ThreadPoolExecutor(num_workers) as executor:
        for result in executor.map(task, what_to_download, chunksize = chunksize):
            result_list.append(result)
            pbar.update(1)
        pbar.close()

    '''
    
    # join the downloaded dataframes
    export, mentions = zip_longest(*result_list)
    export = pd.concat(export)
    mentions = pd.concat(mentions)
    
    # save the result on disk
    export.to_csv('../data/events.tsv', sep = '\t', header = False, index = False, mode = 'a')
    mentions.to_csv('../data/mentions.tsv', sep = '\t', header = False, index = False, mode = 'a')
    
    # update the data record
    update_record(data_record_dict, downloaded)
    
    return

def read_events(usecols = None, skiprows=None, skipfooter=0, nrows=None, iterator=False, chunksize=None, parse_dates = True, **kwargs):
    '''
    usecols:     list-like or callable, optional
                 Return a subset of the columnsIf list-like, all elements must either be positional (i.e. integer indices into the document columns) or strings that correspond to column names provided either by the user in names or inferred from the document header row(s).
    skiprows:    list-like, int or callable, optional
                 Line numbers to skip (0-indexed) or number of lines to skip (int) at the start of the file.
                 If callable, the callable function will be evaluated against the row indices, returning True if the row should be skipped and False otherwise. An example of a valid callable argument would be lambda x: x in [0, 2].
 
    skipfooter:  int, default 0
                 Number of lines at bottom of file to skip (Unsupported with engine=’c’).
 
    nrows:       int, optional
                 Number of rows of file to read. Useful for reading pieces of large files.
 
    iterator:    bool, default False
                 Return TextFileReader object for iteration or getting chunks with get_chunk().
 
    chunksize:   int, optional
                 Return TextFileReader object for iteration. See the IO Tools docs for more information on iterator and chunksize.
    '''
    
    if parse_dates == True and (iterator is not False or chunksize is not None):
        raise ValueError("I can't parse dates with an iterator!! Set parse_dates = False and parse them by and at each iteration.")
    
    event_header = load_pickle('../data_utils/event_header.pickle')
    events = pd.read_csv('../data/events.tsv', sep = '\t', names = event_header.keys(), dtype = event_header, usecols = usecols, skiprows=skiprows, skipfooter=skipfooter, nrows=nrows, iterator=iterator, chunksize=chunksize, **kwargs)
    
    if parse_dates:
        # convert date columns to datetime objects
        if usecols is None:
            usecols = ['DATEADDED']
        if 'DATEADDED' in usecols:
            events['DATEADDED'] = pd.to_datetime(events['DATEADDED'],format='%Y%m%d%H%M%S')
    return(events)

def read_mentions(usecols = None, skiprows=None, skipfooter=0, nrows=None, iterator=False, chunksize=None, parse_dates = True, **kwargs):
    '''
    usecols:     list-like or callable, optional
                 Return a subset of the columnsIf list-like, all elements must either be positional (i.e. integer indices into the document columns) or strings that correspond to column names provided either by the user in names or inferred from the document header row(s).
    skiprows:    list-like, int or callable, optional
                 Line numbers to skip (0-indexed) or number of lines to skip (int) at the start of the file.
                 If callable, the callable function will be evaluated against the row indices, returning True if the row should be skipped and False otherwise. An example of a valid callable argument would be lambda x: x in [0, 2].
 
    skipfooter:  int, default 0
                 Number of lines at bottom of file to skip (Unsupported with engine=’c’).
 
    nrows:       int, optional
                 Number of rows of file to read. Useful for reading pieces of large files.
 
    iterator:    bool, default False
                 Return TextFileReader object for iteration or getting chunks with get_chunk().
 
    chunksize:   int, optional
                 Return TextFileReader object for iteration. See the IO Tools docs for more information on iterator and chunksize.
    '''
    
    if parse_dates == True and (iterator is not False or chunksize is not None):
        raise ValueError("I can't parse dates with an iterator!! Set parse_dates = False and parse them by and at each iteration.")
    
    mention_header = load_pickle('../data_utils/mention_header.pickle')
    mentions = pd.read_csv('../data/mentions.tsv', sep = '\t', names = mention_header.keys(), dtype = mention_header, usecols = usecols, skiprows=skiprows, skipfooter=skipfooter, nrows=nrows, iterator=iterator, chunksize=chunksize, **kwargs)
    
    if parse_dates:
        # convert date columns to datetime objects
        if usecols is None:
            usecols = ['EventTimeDate', 'MentionTimeDate']
        if 'EventTimeDate' in usecols:
            mentions['EventTimeDate'] = pd.to_datetime(mentions['EventTimeDate'],format='%Y%m%d%H%M%S')
        if 'MentionTimeDate' in usecols:
            mentions['MentionTimeDate'] = pd.to_datetime(mentions['MentionTimeDate'],format='%Y%m%d%H%M%S')
    return(mentions)

def headers():
    event_header = load_pickle('../data_utils/event_header.pickle')
    mention_header = load_pickle('../data_utils/mention_header.pickle')
    return(event_header, mention_header)
def read_processed(usecols = None, skiprows=None, skipfooter=0, nrows=None, iterator=False, chunksize=None, **kwargs):
    '''
    usecols:     list-like or callable, optional
                 Return a subset of the columnsIf list-like, all elements must either be positional (i.e. integer indices into the document columns) or strings that correspond to column names provided either by the user in names or inferred from the document header row(s).
    skiprows:    list-like, int or callable, optional
                 Line numbers to skip (0-indexed) or number of lines to skip (int) at the start of the file.
                 If callable, the callable function will be evaluated against the row indices, returning True if the row should be skipped and False otherwise. An example of a valid callable argument would be lambda x: x in [0, 2].
 
    skipfooter:  int, default 0
                 Number of lines at bottom of file to skip (Unsupported with engine=’c’).
 
    nrows:       int, optional
                 Number of rows of file to read. Useful for reading pieces of large files.
 
    iterator:    bool, default False
                 Return TextFileReader object for iteration or getting chunks with get_chunk().
 
    chunksize:   int, optional
                 Return TextFileReader object for iteration. See the IO Tools docs for more information on iterator and chunksize.
    '''
    
    mins=["A_min", 'A2_min', 'B_min', 'C_min', 'D_min']
    maxs=["A_max", 'A2_max', 'B_max', 'C_max', 'D_max']
    counts=["A_count", 'A2_count', 'B_count', 'C_count', 'D_count']
    
    processed_header = load_pickle('../data_utils/processed_header.pickle')
    df = pd.read_csv('../data/group_DF.tsv', sep = '\t' , dtype = processed_header, index_col=0, usecols = usecols, skiprows=skiprows, skipfooter=skipfooter, nrows=nrows, iterator=iterator, chunksize=chunksize, **kwargs)
    df.loc[:, mins+maxs]=df.loc[:, mins+maxs].apply(lambda x: x*timedelta(minutes=15) )
    
    return(df)

def read_processed_day1(usecols = None, skiprows=None, skipfooter=0, nrows=None, iterator=False, chunksize=None, **kwargs):
    '''
    usecols:     list-like or callable, optional
                 Return a subset of the columnsIf list-like, all elements must either be positional (i.e. integer indices into the document columns) or strings that correspond to column names provided either by the user in names or inferred from the document header row(s).
    skiprows:    list-like, int or callable, optional
                 Line numbers to skip (0-indexed) or number of lines to skip (int) at the start of the file.
                 If callable, the callable function will be evaluated against the row indices, returning True if the row should be skipped and False otherwise. An example of a valid callable argument would be lambda x: x in [0, 2].
 
    skipfooter:  int, default 0
                 Number of lines at bottom of file to skip (Unsupported with engine=’c’).
 
    nrows:       int, optional
                 Number of rows of file to read. Useful for reading pieces of large files.
 
    iterator:    bool, default False
                 Return TextFileReader object for iteration or getting chunks with get_chunk().
 
    chunksize:   int, optional
                 Return TextFileReader object for iteration. See the IO Tools docs for more information on iterator and chunksize.
    '''
    
    processed_header = load_pickle('../data_utils/processed_header_day1.pickle')
    df = pd.read_csv('../data/group_DF_day1.tsv', sep = '\t' , dtype = processed_header, index_col=0, usecols = usecols, skiprows=skiprows, skipfooter=skipfooter, nrows=nrows, iterator=iterator, chunksize=chunksize, **kwargs)
    df.loc[:,['A_min', 'A_max']]=df.loc[:, ['A_min', 'A_max']].apply(lambda x: x*timedelta(minutes=15) )
    
    return(df)
